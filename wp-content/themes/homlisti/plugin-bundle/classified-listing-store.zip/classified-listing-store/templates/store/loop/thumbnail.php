<?php

global $store;

?>
<div class="store-thumb">
    <?php $store->the_logo(); ?>
</div>
