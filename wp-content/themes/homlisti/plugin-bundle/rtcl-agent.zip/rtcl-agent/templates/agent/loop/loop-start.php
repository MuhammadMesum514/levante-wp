<?php
/**
 * @package rtcl-agent/templates
 * @version 1.0.0
 */

defined('ABSPATH') || exit();
?>
<div class="rtcl">
    <div <?php rtcl_agent_loop_start_class(); ?>>
