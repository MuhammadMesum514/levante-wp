<?php
/**
 * Agent Sidebar
 *
 * @package     rtcl-agent/templates/agent
 * @version     1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

get_sidebar('agent');

/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
