<?php

echo "Silent is golden. :)";