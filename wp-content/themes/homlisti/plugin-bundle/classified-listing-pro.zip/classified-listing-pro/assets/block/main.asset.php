<?php return array('dependencies' => array('jquery', 'react', 'react-dom', 'wp-blocks', 'wp-components', 'wp-element', 'wp-i18n'), 'version' => '64d4a217daf459fb7b89');
